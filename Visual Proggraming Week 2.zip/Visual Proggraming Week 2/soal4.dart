// library_system.dart

class Book {
  String title;
  String author;
  int year;

  Book(this.title, this.author, this.year);

  @override
  String toString() {
    return 'Title: $title, Author: $author, Year: $year';
  }
}

class Library {
  List<Book> books = [];

  void addBook(Book book) {
    books.add(book);
    print('Book added: ${book.title}');
  }

  void removeBook(String title) {
    books.removeWhere((book) => book.title == title);
    print('Book removed: $title');
  }

  void displayBooks() {
    if (books.isEmpty) {
      print('No books in the library.');
    } else {
      print('Books in the library:');
      for (var book in books) {
        print(book);
      }
    }
  }
}

void main() {
  var library = Library();

  var book1 = Book('The Great Gatsby', 'F. Scott Fitzgerald', 1925);
  var book2 = Book('1984', 'George Orwell', 1949);
  var book3 = Book('To Kill a Mockingbird', 'Harper Lee', 1960);

  library.addBook(book1);
  library.addBook(book2);
  library.addBook(book3);

  library.displayBooks();

  library.removeBook('1984');

  library.displayBooks();
}