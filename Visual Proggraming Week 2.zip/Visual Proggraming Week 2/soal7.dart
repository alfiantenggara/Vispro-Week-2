import 'package:flutter/material.dart';

void main() {
  runApp(VehicleApp());
}

class VehicleApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: VehicleHome(),
    );
  }
}

class VehicleHome extends StatefulWidget {
  @override
  _VehicleHomeState createState() => _VehicleHomeState();
}

class _VehicleHomeState extends State<VehicleHome> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _speedController = TextEditingController();
  String _selectedVehicle = 'Car';
  String _moveDescription = '';

  void _createAndMoveVehicle() {
    String name = _nameController.text;
    double speed = double.tryParse(_speedController.text) ?? 0.0;
    Vehicle vehicle;

    if (_selectedVehicle == 'Car') {
      vehicle = Car(name, speed);
    } else {
      vehicle = Bike(name, speed);
    }

    setState(() {
      _moveDescription = vehicle.move();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Vehicle Creator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Enter vehicle name',
              ),
            ),
            TextField(
              controller: _speedController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter vehicle speed',
              ),
            ),
            SizedBox(height: 20),
            DropdownButton<String>(
              value: _selectedVehicle,
              onChanged: (String? newValue) {
                setState(() {
                  _selectedVehicle = newValue!;
                });
              },
              items: <String>['Car', 'Bike']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _createAndMoveVehicle,
              child: Text('Create and Move'),
            ),
            SizedBox(height: 20),
            Text(
              _moveDescription,
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class Vehicle {
  String name;
  double speed;

  Vehicle(this.name, this.speed);

  String move() {
    return '';
  }
}

class Car extends Vehicle {
  Car(String name, double speed) : super(name, speed);

  @override
  String move() {
    return 'The car moves fast on roads';
  }
}

class Bike extends Vehicle {
  Bike(String name, double speed) : super(name, speed);

  @override
  String move() {
    return 'The bike moves swiftly through traffic';
  }
}