// soal5.dart

// Definisikan kelas abstrak Animal
abstract class Animal {
  void sound();
  void eat();
}

// Implementasi kelas Dog yang mengikuti perilaku Animal
class Dog extends Animal {
  @override
  void sound() {
    print('Dog barks');
  }

  @override
  void eat() {
    print('Dog eats');
  }
}

// Implementasi kelas Cat yang mengikuti perilaku Animal
class Cat extends Animal {
  @override
  void sound() {
    print('Cat meows');
  }

  @override
  void eat() {
    print('Cat eats');
  }
}

void main() {
  // Membuat instance dari Dog dan Cat
  Animal myDog = Dog();
  Animal myCat = Cat();

  // Memanggil metode sound dan eat
  myDog.sound();
  myDog.eat();

  myCat.sound();
  myCat.eat();
}