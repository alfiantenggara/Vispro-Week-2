import 'package:flutter/material.dart';

void main() {
  runApp(TemperatureConverterApp());
}

class TemperatureConverterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: TemperatureConverter(),
    );
  }
}

class TemperatureConverter extends StatefulWidget {
  @override
  _TemperatureConverterState createState() => _TemperatureConverterState();
}

class _TemperatureConverterState extends State<TemperatureConverter> {
  final TextEditingController _controller = TextEditingController();
  String _selectedUnit = 'Reaumur';
  double _result = 0.0;

  void _convertTemperature() {
    double celsius = double.tryParse(_controller.text) ?? 0.0;
    setState(() {
      if (_selectedUnit == 'Reaumur') {
        _result = celsius * 0.8;
      } else if (_selectedUnit == 'Fahrenheit') {
        _result = (celsius * 9 / 5) + 32;
      } else if (_selectedUnit == 'Kelvin') {
        _result = celsius + 273.15;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Temperature Converter'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter temperature in Celsius',
              ),
            ),
            SizedBox(height: 20),
            DropdownButton<String>(
              value: _selectedUnit,
              onChanged: (String? newValue) {
                setState(() {
                  _selectedUnit = newValue!;
                });
              },
              items: <String>['Reaumur', 'Fahrenheit', 'Kelvin']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _convertTemperature,
              child: Text('Convert'),
            ),
            SizedBox(height: 20),
            Text(
              'Result: ${_result.toStringAsFixed(2)} $_selectedUnit',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}