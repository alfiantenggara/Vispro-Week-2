class Student {
  String name;
  String studentID;
  double grade;

  Student(this.name, this.studentID, this.grade);

  void displayInfo() {
    print('Name: $name');
    print('Student ID: $studentID');
    print('Grade: $grade');
  }

  bool isPassing() {
    return grade >= 70;
  }
}

void main() {
  // Contoh penggunaan kelas Student
  var student1 = Student('piang', 'S12345', 75.5);
  student1.displayInfo();
  print('Passing status: ${student1.isPassing() ? 'Passed' : 'Failed'}');
}