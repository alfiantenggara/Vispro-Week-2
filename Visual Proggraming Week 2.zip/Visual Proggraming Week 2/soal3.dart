class ATM {
  // Private variable to store the balance
  double _balance = 0.0;

  // Method to deposit money
  void deposit(double amount) {
    if (amount > 0) {
      _balance += amount;
      print('Deposited: \$${amount.toStringAsFixed(2)}');
    } else {
      print('Invalid deposit amount');
    }
  }

  // Method to withdraw money
  void withdraw(double amount) {
    if (amount > 0 && amount <= _balance) {
      _balance -= amount;
      print('Withdrew: \$${amount.toStringAsFixed(2)}');
    } else {
      print('Invalid withdrawal amount or insufficient balance');
    }
  }

  // Method to check balance
  double get balance {
    return _balance;
  }
}

void main() {
  ATM atm = ATM();

  atm.deposit(100.0);
  atm.withdraw(50.0);
  print('Current balance: \$${atm.balance.toStringAsFixed(2)}');
}