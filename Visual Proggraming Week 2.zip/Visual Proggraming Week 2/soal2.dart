class BankAccount {
  double _balance;

  BankAccount(this._balance);

  void deposit(double amount) {
    if (amount > 0) {
      _balance += amount;
      print('Deposited: \$${amount}');
    } else {
      print('Deposit amount must be positive.');
    }
  }

  void withdraw(double amount) {
    if (amount > 0 && amount <= _balance) {
      _balance -= amount;
      print('Withdrew: \$${amount}');
    } else {
      print('Invalid withdraw amount.');
    }
  }

  double checkBalance() {
    return _balance;
  }
}

class SavingsAccount extends BankAccount {
  double interestRate;

  SavingsAccount(double balance, this.interestRate) : super(balance);

  void applyInterest() {
    double interest = _balance * (interestRate / 100);
    deposit(interest);
    print('Interest applied: \$${interest}');
  }
}

void main() {
  // Contoh penggunaan kelas BankAccount dan SavingsAccount
  var account = BankAccount(1000);
  account.deposit(500);
  account.withdraw(200);
  print('Current Balance: \$${account.checkBalance()}');

  var savings = SavingsAccount(1000, 5);
  savings.applyInterest();
  print('Savings Balance after interest: \$${savings.checkBalance()}');
}